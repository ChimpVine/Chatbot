from flask import Flask, request, jsonify, send_file, render_template
import wolframalpha
import requests
from PIL import Image
from io import BytesIO
import numpy as np
import cv2

app_id = 'QYQY68-4ERVU37E82'
client = wolframalpha.Client(app_id)

app = Flask(__name__)

def get_plot_url(equation):
    try:
        res = client.query(equation)
        for pod in res.pods:
            if 'Plot' in pod.title or 'plot' in pod.title:
                return next(subpod.img.src for subpod in pod.subpods)
    except Exception as e:
        return str(e)
    return None

def upscale_image(image):
    cv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
    upscale_factor = 2
    upscaled_image = cv2.resize(cv_image, (cv_image.shape[1] * upscale_factor, cv_image.shape[0] * upscale_factor), interpolation=cv2.INTER_CUBIC)
    upscaled_pil_image = Image.fromarray(cv2.cvtColor(upscaled_image, cv2.COLOR_BGR2RGB))
    return upscaled_pil_image

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/plot', methods=['POST'])
def plot_equation():
    data = request.json
    equation = data.get('equation', '')
    plot_url = get_plot_url(equation)
    if plot_url:
        response = requests.get(plot_url)
        img = Image.open(BytesIO(response.content))
        upscaled_img = upscale_image(img)
        img_io = BytesIO()
        upscaled_img.save(img_io, 'PNG')
        img_io.seek(0)
        return send_file(img_io, mimetype='image/png')
    else:
        return jsonify({'error': 'No plot found for the given equation.'}), 404

if __name__ == '__main__':
    app.run(debug=True)
